/* Set rates + misc */
let taxRate = 0.2,
    shippingRate = 0,
    fadeTime = 300;

/* Assign actions */
$('.product-quantity select').change(function () {
  updateQuantity(this);
});

$('.product-removal img').click(function () {
  removeItem(this);
});

/* Recalculate cart */
const recalculateCart = () => {
  let subtotal = 0;

  /* Sum up row totals */
  $('.product').each(function () {
    subtotal += parseFloat($(this).children('.product-line-price').text());
  });

  /* Calculate totals */
  let tax = subtotal * taxRate,
      shipping = (subtotal > 0 ? shippingRate : 0),
      total = subtotal + tax + shipping;

  /* Update totals display */
  $('.totals-value').fadeOut(fadeTime, function () {
    $('#cart-subtotal').html(subtotal.toFixed(2));
    $('#cart-tax').html(tax.toFixed(2));
    $('#cart-shipping').html(shipping.toFixed(2));
    $('#cart-total').html(total.toFixed(2));
    if (total == 0) {
      $('.checkout').fadeOut(fadeTime);
    } else {
      $('.checkout').fadeIn(fadeTime);
    }
    $('.totals-value').fadeIn(fadeTime);
  });
}

/* Update quantity */
const updateQuantity = quantityInput => {
  console.log(quantityInput);
  /* Calculate line price */
  let productRow = $(quantityInput).parent().parent().parent().parent().parent(),
      price = parseFloat(productRow.find('.product-price').text()),
      quantity = $(quantityInput).val(),
      linePrice = price * quantity;

  /* Update line price display and recalc cart totals */
  productRow.children('.product-line-price').each(function () {
    $(this).fadeOut(fadeTime, function () {
      $(this).text(linePrice.toFixed(2));
      recalculateCart();
      $(this).fadeIn(fadeTime);
    });
  });
}

/* Remove item from cart */
const removeItem = removeButton => {
  /* Remove row from DOM and recalc cart total */
  let productRow = $(removeButton).parent().parent();
  productRow.slideUp(fadeTime, function () {
    productRow.remove();
    $('.item-quantity span').text($('.product').length);
    recalculateCart();
  });
}

$('button.checkout').click(function (e) {
  e.preventDefault();

  let cart = [],
    item = [],
    total = [];

  $('.product').each(function () {
    item.push({
      'name': $('.product-title', this).text(),
      'price': $('.product-price', this).text(),
      'quantity': $('select option:selected', this).val(),
      'totalPrice': $('.product-line-price', this).text()
    });
  });
  total.push({
    subTotal: $('#cart-subtotal').text(),
    vat: $('#cart-tax').text(),
    totalCost: $('#cart-total').text()
  });

  let items = [item, total];
  cart.push(items);
  console.log(JSON.stringify(cart));

  //Post JSON Shooping Data
  $.post("http://localhost:3000/thankyou.html", function (cart) {
      alert(JSON.stringify(cart));
    })
    .fail(function () {
      alert(JSON.stringify(cart));
      alert("While Posting Error Occured: As this is a localhost.");
    })
    .always(function () {
      alert("Finished Call");
    });
});