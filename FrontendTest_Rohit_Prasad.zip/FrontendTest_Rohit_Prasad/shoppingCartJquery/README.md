# Gulp Sass &amp; JavaScript compiler
A simple Gulp task that takes your project Sass and JavaScript files, optionally minifies them, and creates ready to serve `.css` and `.js` files in a folder of your choice.

## Requirements
- [node.js](https://nodejs.org/)

## Installation
1. Install [node.js](https://nodejs.org/).
2. `cd` into the root of your project folder
3. `npm install`

## Usage
- `gulp` - Running this command starts a watch task. This automatically re-generates your CSS/JS when it detects changes to your source files
- `gulp refresh` - Running this command re-generates your CSS/JS once, and quits when finished