import React from 'react'
class Product extends React.Component {
  constructor(props) {
    super(props);
    this.state = { value: '2' };
    this.price = 198.99
    this.handleChange = this.handleChange.bind(this);
    this.props.quantityHandler(parseInt(this.state.value), this.price)
  }

  handleChange(event) {
    this.setState({ value: event.target.value });
    this.props.quantityHandler(parseInt(event.target.value), this.price)
  }


  render() {
    return (
      <div className="product">
        <div className="product-details">
          <div className="product-image"><img src={require('./../Images/product-thumbnail.jpg')} alt="product picture" /></div>
          <div className="product-description">
            <div className="product-title">Lorem ipsum de amet</div>
            <div className="product-priceQuantity">
              <div className="product-price">$ {this.price}</div>
              <div className="product-quantity">
                <select value={this.state.value} onChange={this.handleChange}>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div className="product-line-price"><span></span> $ {this.state.value * this.price}</div>
        <div className="product-removal">
          <img src={require('./../Images/delete-icon.png')} alt="Remove Item" />
        </div>
      </div>
    )
  }
}
export default Product;