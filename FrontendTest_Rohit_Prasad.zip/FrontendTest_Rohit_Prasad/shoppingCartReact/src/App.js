import React from 'react';
import './App.scss';
import Product from './Product/Product';

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      total: 0,
      vat: 0,
      final: 0,
      items: 0
    }

    this.quantityChange = this.quantityChange.bind(this);
  }

  quantityChange(quantity, price) {
    const total = quantity * price;
    console.log("this.state.total", this.state.total)

    /* `dont change */
    const vat = total * .2
    const final = total + vat
    const items = quantity
    this.setState({
      total: total,
      vat: vat,
      final: final,
      items: items
    })
  }

  render() {
    return (
      <div className="shopping-cart" >
        <header>
          <img src={require('./Images/akqa-logo.svg')} alt="logo" />
        </header>
        <div class="item-quantity">You have {this.state.items} item(s) in your cart</div>
        <div className="column-labels">
          <label className="product-details">Product</label>
          <label className="product-line-price">Total Cost</label>
          <label className="product-removal">Remove</label>
        </div>

        <Product quantityHandler={this.quantityChange} />
        <Product quantityHandler={this.quantityChange} />

        <div className="totals" >
          <div className="totals-item">
            <label>Subtotal: </label>
            <div className="totals-value" id="cart-subtotal">$ {this.state.total}</div>
          </div>
          <div className="totals-item">
            <label>VAT @ 20%: </label>
            <div className="totals-value" id="cart-tax">$ {this.state.vat}</div>
          </div>
          <div className="totals-item totals-item-total">
            <label>Total Cost: </label>
            <div className="totals-value" id="cart-total">$ {this.state.final}</div>
          </div>
        </div>
        <button className="checkout">BUY NOW >></button>
      </div>
    );
  }
}

export default App;